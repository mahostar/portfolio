import Image from "next/image";
import Link from "next/link";
import { ArrowUpRight, Bot, CircuitBoard, Cpu, Film, Gamepad2, Waves, Wind } from "lucide-react";
import { getImpact, getInterests, getJourney } from "@/lib/content";
import { Eyebrow } from "./section-heading";

export function Journey() {
  return <section id="journey" className="section journey-section" aria-labelledby="journey-heading"><div className="container journey-grid">
    <div className="journey-intro"><Eyebrow>Building my own path</Eyebrow><h2 id="journey-heading" className="large-heading">My Journey</h2><p>From studying systems to building them, teaching them, and leading the work.</p><p className="journey-note">The roles in 2025–2026 overlapped: an intensive chapter of engineering, teaching, and leadership.</p></div>
    <ol className="journey-list">{getJourney().map((item, index) => <li key={item.id} className={item.kind === "Planned" ? "journey-planned" : ""}>
      <span className="journey-index" aria-hidden="true">{String(index + 1).padStart(2, "0")}</span>
      <div className="journey-entry"><div className="journey-meta"><span>{item.period}</span><span className="story-badge">{item.kind}</span></div><h3>{item.title}</h3><p className="journey-organization">{item.organization}</p><p>{item.description}</p>{item.href && <Link className="text-link" href={item.href} {...(item.href.startsWith("https:") ? { target: "_blank", rel: "noreferrer" } : {})}>{item.linkLabel}<ArrowUpRight size={16} /></Link>}</div>
    </li>)}</ol>
  </div></section>;
}

const impactIcons = { robotics: Bot, ai: Cpu, pcb: CircuitBoard };
export function ImpactShowcase() {
  return <section id="impact" className="section impact-section" aria-labelledby="impact-heading"><div className="container">
    <div className="story-heading"><div><Eyebrow>Knowledge put into practice</Eyebrow><h2 id="impact-heading">Impact Showcase</h2></div><p>Engineering also means sharing what you know. A few stories from the classroom and the workshop.</p></div>
    <div className="impact-grid">{getImpact().map((item, index) => { const Icon = impactIcons[item.motif]; return <article key={item.id} className={`impact-card impact-${item.motif}`}>
      <div className="impact-visual">{item.image ? <Image src={item.image} alt={item.alt} fill sizes={index === 0 ? "(max-width: 767px) 100vw, 65vw" : "(max-width: 767px) 100vw, 33vw"} /> : <><div className="impact-art" aria-hidden="true"><Icon strokeWidth={1} /><span className="art-orbit orbit-one" /><span className="art-orbit orbit-two" /><span className="art-coordinate">{String(index + 1).padStart(2, "0")} / FABLAB</span></div><span className="photo-pending">{item.photoLabel}</span></>}</div>
      <div className="impact-copy"><p className="eyebrow">{item.category}</p><h3>{item.title}</h3><p>{item.description}</p></div>
    </article>; })}</div>
  </div></section>;
}

const interestIcons = { windsurfing: Wind, swimming: Waves, gaming: Gamepad2, cinema: Film };
export function BeyondEngineering() {
  return <section id="interests" className="section interests-section" aria-labelledby="interests-heading"><div className="container">
    <div className="story-heading"><div><h2 id="interests-heading">Beyond Engineering</h2></div></div>
    <div className="interests-grid">{getInterests().map((item) => { const Icon = interestIcons[item.id]; return <article className={`interest-card interest-${item.id}`} key={item.id}><div className="interest-icon" aria-hidden="true"><Icon size={32} strokeWidth={1.5} /></div><p className="interest-detail">{item.detail}</p><h3>{item.title}</h3><p>{item.description}</p></article>; })}</div>
  </div></section>;
}
